---
name: scan
description: Scan paper to PDF on the borrowed Fujitsu ScanSnap iX500 (USB document scanner), then analyze and organize the result. Use whenever the user wants to scan or digitize paper — "scan this", "make a PDF of these pages", "digitize my notes" — or mentions the scanner, ScanSnap, iX500, the feeder, or scanner problems (not found, blank output, not feeding, jams). ALSO use when the user wants a scanned batch analyzed, split, renamed, or filed — "organize my scans", "split out the checks", "what's in this scan" — even without rescanning. Handles first-time software setup automatically.
---

# Scanning on the ScanSnap iX500 (borrowed scanner)

USB document scanner with a ~50-sheet automatic feeder. Runs on an open-source
stack (SANE `fujitsu` backend + img2pdf) — the official ScanSnap software is
dead on modern macOS and must NOT be installed.

## Quick facts

| Thing | Value |
|---|---|
| Power switch | **The lid.** Scanner invisible to the Mac → lid is closed. Blue light = on. |
| Connection | USB only, plugged **directly** into the Mac (flaky on USB-3 hubs). WiFi will never work with this stack — don't burn time on it. |
| Paper | Face-DOWN, top edge first, ~50 sheets max in the feeder |
| Scan command | `scan2pdf [name]` → `~/Documents/Scans/<name>-YYYYMMDD-HHMMSS.pdf` |
| Defaults | double-sided (duplex), color, 300 dpi, JPEG pages |
| Diagnostics | `scan-diag` — pass/fail per check with a fix hint; changes nothing |
| Organizer | `scan-organize plan.json` — splits a batch PDF per your page plan |

## First-time setup

Run once (idempotent — safe to rerun any time something seems missing):

    bash <skill-base-dir>/setup.sh

It checks Homebrew, installs `sane-backends` + `img2pdf` + `poppler`
(required — poppler drives analysis and splitting) and `imagemagick`
(optional, for preview grids), enables the `fujitsu` backend in SANE's
dll.conf, and symlinks `scan2pdf` / `scan-diag` / `scan-organize` into
`~/bin`. If `~/bin` is not on PATH, run the tools by absolute path from
this skill's `bin/` directory — they work in place.

Then have the user plug in the scanner (power brick + USB) and OPEN THE LID,
and verify: `scan-diag`. All checks green → ready.

## Scanning

1. Confirm paper is loaded face-down, top edge first, lid open. If the user
   just asked to scan, they probably already loaded it — just run it.
2. Run `scan2pdf <short-name>` (e.g. `scan2pdf essay`). Useful options:
   `-s` front sides only · `-g` grayscale · `-r N` dpi · `-o DIR` output dir ·
   `--open` open the PDF in Preview when done · `-k` keep page images ·
   `-x ARG` pass a raw option to scanimage (repeatable).
3. Report the output path to the user.
4. Duplex keeps blank backs in the PDF — for one-sided documents prefer `-s`.
5. Scanner stderr is chatty (`Progress:` spam, `scanner status = 5`, a final
   "Document feeder out of documents") — all normal. Filter with
   `2>&1 | tr '\r' '\n' | grep -v "^Progress"`.

## Verify (recommended for multi-page jobs)

Orientation bugs are invisible to page counts — render a strip and LOOK at it:

    pdftoppm -png -r 25 out.pdf p && magick p-*.png -border 2 +append -resize 2400x strip.png

Read strip.png, confirm pages are upright and present, then delete the temp
images (don't leave them lying around).

## Analyze & organize (do this after every batch scan)

A raw batch scan is one anonymous PDF of mixed paper. The value step is
turning it into named, filed documents. Offer/do this right after scanning,
and also on request against any existing PDF in `~/Documents/Scans`.

**1. Look at every page.** Render pages at readable resolution and actually
read them — classification by filename or page count alone gets it wrong:

    pdftoppm -png -r 100 batch.pdf page

100 dpi is enough to read check numbers, payees, amounts, and statement
headers. View the images (a preview grid at 25 dpi is fine for a first
orientation/blank-page pass; go to the 100 dpi single pages for anything you
need to read). In a duplex scan, page 2N is the back of page 2N-1 — use that
pairing when deciding what a back side belongs to.

**2. Classify into documents.** Types get their own subfolder under
`~/Documents/Scans/` — `Checks/`, `Statements/`, `Receipts/`, `Letters/`,
and new type folders as the paper warrants; truly unclassifiable pages go in
`Misc/`. Grouping rules:

- **Checks: one PDF per check date**, ordered by check number (front, then
  its back right after, when the back is kept). A batch often holds several
  payroll runs — e.g. a Jun 15 run and a Jun 29 run become two PDFs. A stray
  check dated a day off from a run belongs with that run. The check number
  is printed top-right and repeats in the MICR line at the bottom.
- **Everything else: one PDF per logical document** — a multi-page statement
  stays together as one file, in page order.
- **Blank backs are dropped; endorsed/signed/stamped check backs are kept.**
  When unsure whether a back is blank, keep it — dropping information is the
  worse failure.

**3. Name descriptively** (lowercase, hyphenated):

- Checks: `checks-YYYYMMDD-<first>-<last>.pdf` (check date, first/last check
  number in that group), e.g. `checks-20260615-2416-2423.pdf`
- Others: `<type>-<short-descriptor>-<date>.pdf` using the document's own
  date when readable (fall back to scan date), e.g.
  `statement-merchant-billing-2026-05.pdf`

**4. Write a plan and run it.** Write a plan JSON (see `scan-organize
--help` for the schema: source PDF + outputs, each with a relative path and
a 1-based page list in output order), then:

    scan-organize plan.json          # add --dry-run first if unsure

It validates everything before writing, reports any dropped pages so nothing
vanishes silently, and moves the original batch PDF into
`~/Documents/Scans/originals/` — the split is non-destructive and the
original is always recoverable from there.

**5. Verify and report.** Check each output's page count (`pdfinfo`), then
tell the user what went where — one line per document with its page count.
Clean up any rendered page images.

## Searchable PDFs

scan2pdf output is image-only. If the user wants searchable/copyable text:
`brew install ocrmypdf` (once), then `ocrmypdf in.pdf out.pdf`.

## Exit codes → what to do

- **1 (no scanner):** lid probably closed or USB unplugged. Run `scan-diag`,
  relay which check failed and its hint.
- **2 (no pages):** feeder is empty — ask the user to load paper and rerun. If
  they insist paper was loaded, re-square the stack (feed/pickup problem).
- **3 (assembly failed):** rerun with `--keep-pages` so the scanned images
  survive, then debug img2pdf with the kept files.

## Troubleshooting quirks (this exact scanner)

Run `scan-diag` before theorizing. Then, in order of likelihood:

- **Lid.** Always the lid first.
- **USB check:** `system_profiler SPUSBDataType` can return EMPTY on recent
  macOS — use `ioreg -p IOUSB -l -w0 | grep -i ScanSnap` instead. Expect
  idVendor 1221 (0x04c5), idProduct 4907 (0x132b).
- **Mid-batch hangs / dropped pages:** the iX500 is known-flaky on USB-3 hubs.
  First move is moving the cable to a direct port or a USB-2/powered hub.
- **Official ScanSnap software steals the device from SANE.** If
  `pgrep -fil scansnap` shows processes, kill them and recommend uninstalling
  the ScanSnap apps — this stack replaces them entirely. Best: never install.
- **fujitsu backend disabled:** `scan-diag` will say so; fix by uncommenting
  `fujitsu` in `$(brew --prefix)/etc/sane.d/dll.conf` (setup.sh does this).
- Device string is `fujitsu:ScanSnap iX500:<serial>`; the CLIs auto-discover
  it, so you never need to type it.

## GUI alternative

NAPS2 (free, naps2.com) works with the same SANE driver for point-and-click
scanning. The setup kit this skill came in includes `profiles.xml` — with
NAPS2 closed, copy it to `~/.config/naps2/profiles.xml` for ready-made
profiles ("iX500 Duplex" and "iX500 Feeder").

## Returning the scanner

Nothing must be undone. Optional cleanup: `brew uninstall sane-backends
img2pdf`, remove the `~/bin/scan2pdf` and `~/bin/scan-diag` symlinks, delete
this skill folder.
