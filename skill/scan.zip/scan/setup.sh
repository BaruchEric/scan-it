#!/bin/bash
# First-time software setup for the ScanSnap iX500 open-source scanning stack.
# Idempotent — safe to rerun any time. Changes: brew packages, SANE dll.conf,
# ~/bin symlinks. Nothing else.
set -euo pipefail

SKILL_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "== ScanSnap iX500 stack setup =="

# 0) Homebrew is the prerequisite everything else installs through
if ! command -v brew >/dev/null 2>&1; then
  echo "FAIL: Homebrew is not installed. Install it first:"
  echo '  /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"'
  echo "then rerun this script."
  exit 1
fi

# 1) Required: SANE driver stack + PDF assembler + poppler (analysis/splitting)
for pkg in sane-backends img2pdf poppler; do
  if brew list "$pkg" >/dev/null 2>&1; then
    echo "* $pkg already installed"
  else
    echo "Installing $pkg..."
    brew install "$pkg"
  fi
done

# 2) Optional: visual verification of finished PDFs (page strips)
for pkg in imagemagick; do
  if brew list "$pkg" >/dev/null 2>&1; then
    echo "* $pkg already installed"
  else
    brew install "$pkg" || echo "note: $pkg failed to install (optional — scanning still works)"
  fi
done

# 3) The fujitsu backend must be enabled in SANE's dll.conf
DLL="$(brew --prefix)/etc/sane.d/dll.conf"
if [ -f "$DLL" ]; then
  if grep -q '^fujitsu' "$DLL"; then
    echo "* fujitsu backend already enabled"
  elif grep -q '^#fujitsu' "$DLL"; then
    sed -i '' 's/^#fujitsu/fujitsu/' "$DLL"
    echo "* enabled fujitsu backend in $DLL"
  else
    echo "fujitsu" >> "$DLL"
    echo "* added fujitsu backend to $DLL"
  fi
else
  echo "warning: $DLL not found — sane-backends install may have failed"
fi

# 4) Put the CLIs on PATH via ~/bin (they also run fine in place)
mkdir -p "$HOME/bin"
chmod +x "$SKILL_DIR/bin/scan2pdf" "$SKILL_DIR/bin/scan-diag" "$SKILL_DIR/bin/scan-organize" "$SKILL_DIR/bin/escl-scan"
ln -sf "$SKILL_DIR/bin/scan2pdf" "$HOME/bin/scan2pdf"
ln -sf "$SKILL_DIR/bin/scan-diag" "$HOME/bin/scan-diag"
ln -sf "$SKILL_DIR/bin/scan-organize" "$HOME/bin/scan-organize"
ln -sf "$SKILL_DIR/bin/escl-scan" "$HOME/bin/escl-scan"
echo "* scan2pdf, scan-diag, scan-organize and escl-scan linked into ~/bin"
case ":$PATH:" in
  *":$HOME/bin:"*) ;;
  *) echo "  note: ~/bin is not on PATH — use $SKILL_DIR/bin/scan2pdf directly," ;;
esac

# 5) Official ScanSnap software steals the scanner from SANE
if pgrep -fil scansnap >/dev/null 2>&1; then
  echo "WARNING: ScanSnap software is running — it will steal the scanner from SANE."
  echo "         Quit/uninstall the ScanSnap apps; this stack replaces them."
fi

echo ""
echo "Setup complete. Plug in the scanner (power + USB direct to the Mac),"
echo "OPEN THE LID (that's the power switch), then verify with: scan-diag"
